# Mobile Installment V6.0 – Christmas 3D Edition

โปรเจกต์ Android ใหม่ที่สร้างจากข้อกำหนดและภาพตัวอย่างที่ได้รับ โดยใช้ Android Java + WebView + HTML/CSS/JavaScript

## Application ID
`com.example.mobileinstallment`

## เวอร์ชัน
- versionCode: 6
- versionName: 6.0
- minSdk: 23
- compileSdk: 35

## Build
ต้องติดตั้ง Android Studio / Android SDK และ JDK 17 ก่อน จากโฟลเดอร์โปรเจกต์รัน:

```bash
gradle assembleDebug
```

APK จะอยู่ที่:

`app/build/outputs/apk/debug/app-debug.apk`

หรือเปิดโฟลเดอร์นี้ด้วย Android Studio แล้วเลือก Build > Build APK(s)

## หมายเหตุสำคัญ
- ไฟล์นี้เป็น Android Project ที่สร้างใหม่ ไม่ใช่การแก้ source code เดิม เพราะได้รับมาเฉพาะ APK ที่คอมไพล์แล้ว ไม่มี Android Project ZIP เดิม
- Application ID คงตามที่ระบุใน handoff
- การติดตั้งทับ APK เดิมขึ้นอยู่กับ Signing Key ของ APK เดิม หากใช้คนละ key จะติดตั้งทับไม่ได้
- ก่อนเผยแพร่จริง ให้ตรวจสอบ Signing Key เดิมและใช้ key เดียวกัน
- สูตร SG และ S Leasing อยู่ใน `app/src/main/assets/index.html`
- ค่าราคาและส่วนลดเริ่มต้นเป็น 0/ว่างตามข้อกำหนด
- การแชร์บน Android ใช้ Android Share Sheet ผ่าน JavaScript bridge
