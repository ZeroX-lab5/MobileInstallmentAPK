# Mobile Installment V6.0 – Christmas Edition

โปรเจกต์ Android ฉบับแก้ไขต่อได้ ใช้ **Java + Android WebView** โดยออกแบบหน้าคำนวณตามภาพอ้างอิงล่าสุดของผู้ใช้

## ข้อมูลโปรเจกต์
- ชื่อแอปบน Android: **เครื่องคำนวณสินเชื่อ**
- ชื่อโปรเจกต์: `MobileInstallment_Android_Project`
- Application ID: `com.example.mobileinstallment` (คงเดิม)
- versionName: `6.0`
- versionCode: `7`
- minSdk: 23 / compileSdk: 35 / targetSdk: 35
- ไม่มีเพลงคริสต์มาสและไม่มีปุ่มเปิด/ปิดเพลงตามคำขอล่าสุด
- ภาพส่วนหัวใช้ `app/src/main/assets/santa_header_reference.jpg` (ซานต้าถือโทรศัพท์ตามภาพล่าสุด ไม่มีข้อความระบุรุ่นมือถือ)

## โครงสร้างหลัก
- `app/src/main/java/com/example/mobileinstallment/MainActivity.java` — Android Activity, WebView bridge สำหรับแชร์และสั่น
- `app/src/main/assets/index.html` — UI, CSS และ JavaScript เครื่องคำนวณ
- `app/src/main/assets/santa_header_reference.jpg` — ภาพซานต้าส่วนหัว
- `app/src/main/assets/app_logo_original.png` — โลโก้ต้นฉบับสำหรับอ้างอิง
- `app/src/main/res/mipmap-*` — ไอคอนแอป

## สูตรคำนวณ (คงตามข้อกำหนด)
### SG
- ดาวน์จากราคาเต็มก่อน: `Math.round(price * downPercent / 100)`
- ยอดหลังดาวน์ = `Math.max(0, price - downPayment)`
- ส่วนลดถูกจำกัดไม่เกินยอดหลังดาวน์
- ยอดจัด = ยอดหลังดาวน์ - ส่วนลด
- ตัวคูณ: 12 เดือน = 1.12, 18 เดือน = 1.18, 24 เดือน = 1.24
- ค่างวด = `Math.ceil(finance * factor / months)`

### S Leasing
- ราคาหลังส่วนลด = `Math.max(0, price - discount)`
- ดาวน์จากราคาหลังส่วนลด
- ดอกเบี้ย Flat Rate = 1.15% ต่อเดือน
- ค่างวด = `Math.ceil((finance + finance * 0.0115 * months) / months)`

ตัวเลือก SG: ดาวน์ 10/20/30/40/50%, 12/18/24 เดือน
ตัวเลือก S Leasing: ดาวน์ 10/15/20/25/30/35/40/45/50%, 6/9/12/15/18 เดือน

## เปิดและ Build ด้วย Android Studio
1. แตก ZIP
2. เปิด Android Studio แล้วเลือก **Open** โฟลเดอร์ `MobileInstallment_Android_Project`
3. ใช้ JDK 17 และติดตั้ง Android SDK Platform 35
4. รอ Gradle Sync
5. เลือก **Build > Build Bundle(s) / APK(s) > Build APK(s)**
6. APK debug จะอยู่ที่ `app/build/outputs/apk/debug/app-debug.apk`

## การอัปเดตทับแอปเดิม
คง Application ID เดิมและตั้ง versionCode เป็น 7 แล้ว แต่การติดตั้งทับแอปเดิมยังรับประกันไม่ได้จนกว่าจะใช้ Signing Key เดิมของแอปที่ติดตั้งอยู่ หากไม่มี keystore เดิม อาจต้องถอนแอปเก่าก่อนติดตั้ง APK ใหม่ ซึ่งอาจทำให้ข้อมูลแอปเดิมหาย

## สถานะการตรวจสอบ
- ตรวจสอบโครงสร้างโปรเจกต์และ ZIP
- ตรวจ JavaScript syntax ด้วย `node --check`
- ตรวจตัวอย่าง S Leasing: ราคา 43,999 บาท / ส่วนลด 500 บาท / ดาวน์ 10% ได้ 6,976, 4,801, 3,713, 3,061 และ 2,626 บาทต่อเดือน สำหรับ 6, 9, 12, 15 และ 18 เดือนตามลำดับ
- ยังไม่ได้ Build APK ด้วย Android SDK/Gradle ในสภาพแวดล้อมนี้ และยังไม่ได้ติดตั้งทดสอบบนโทรศัพท์จริง
