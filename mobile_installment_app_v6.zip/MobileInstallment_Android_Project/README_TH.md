# เครื่องคำนวณสินเชื่อ – Mobile Installment V6.0 Christmas 3D

Android Project (Java + WebView) สำหรับเปิดและ Build ด้วย Android Studio

- Application ID: `com.example.mobileinstallment`
- ชื่อแอปบน Android: `เครื่องคำนวณสินเชื่อ`
- versionCode: 6
- versionName: 6.0
- minSdk: 23
- compileSdk: 35

## ภาพต้นฉบับ
- `app/src/main/assets/app_logo_original.png` — โลโก้ซานต้าถือเครื่องคิดเลข
- `app/src/main/assets/screen_reference_original.png` — ภาพต้นแบบหน้าคำนวณ
- ไอคอน Launcher สร้างจากโลโก้ที่ผู้ใช้ส่งมา

## สูตร
สูตร SG และ S Leasing อยู่ใน `app/src/main/assets/index.html` โดยคงลำดับการคิดตามข้อกำหนด:
- SG: คำนวณเงินดาวน์จากราคาเต็มก่อน แล้วหักส่วนลดจากยอดหลังดาวน์
- S Leasing: หักส่วนลดก่อน แล้วคำนวณเงินดาวน์จากราคาหลังหักส่วนลด

## Build APK
ต้องมี Android Studio, Android SDK Platform 35 และ JDK 17
1. เปิดโฟลเดอร์ `MobileInstallment_Android_Project` ใน Android Studio
2. รอ Gradle Sync
3. เลือก Build > Build Bundle(s) / APK(s) > Build APK(s)
4. APK อยู่ที่ `app/build/outputs/apk/debug/app-debug.apk`

## Signing / อัปเดตทับ
การติดตั้งทับแอปเดิมต้องใช้ Signing Key เดิมและ versionCode สูงกว่า โปรเจกต์นี้ยังไม่ได้รับ keystore เดิม จึงไม่รับประกันการอัปเดตทับ

## สถานะการทดสอบ
ตรวจสอบไฟล์ ZIP และไฟล์ต้นฉบับแล้ว แต่ยังไม่ได้ Build APK หรือทดสอบติดตั้งบนอุปกรณ์จริงในสภาพแวดล้อมนี้
