โปรเจกต์แอปคำนวณเงินดาวน์ OPPO SG+ ตามตารางโปรโมชั่นที่ผู้ใช้ส่งมา

ข้อมูลที่รองรับ:
- OPPO FIND X9S 5G 12/256GB
- OPPO RENO 16F 5G 8/128GB
- OPPO RENO 16F 5G 8/256GB
- OPPO RENO 16 5G 8/256GB
- OPPO RENO 16 5G 12/256GB
- OPPO RENO 16 5G 12/512GB

เลือกเปอร์เซ็นต์ดาวน์ 10/20/30/40/50% และระยะ 12/18/24 งวด
ตัวเลขเงินดาวน์ เงินที่ลูกค้าจ่ายเพิ่ม และค่างวดใช้ค่าจากตารางโดยตรง
ไฟล์ Android WebView อยู่ใน mobile_installment_app/
สำหรับ GitHub Actions ให้อัปโหลดไฟล์ ZIP นี้เข้า Repository โดยใช้ชื่อ MobileInstallment_Android_Project.zip
