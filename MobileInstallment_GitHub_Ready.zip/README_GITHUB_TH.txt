คู่มือเริ่มต้นใหม่ — Mobile Installment

โครงสร้างที่ต้องอยู่ในหน้าแรกของ GitHub Repository:

.github/
  workflows/
    build-apk.yml
mobile_installment_app/
  app/
  build.gradle
  settings.gradle
  gradle.properties
  README_TH.txt
  Demo.html

วิธีใช้งาน:
1. แตกไฟล์ MobileInstallment_GitHub_Ready.zip
2. นำโฟลเดอร์ .github และ mobile_installment_app ไปไว้ที่หน้าแรกของ Repository เดิม
3. แทนที่ไฟล์เดิมเมื่อระบบถาม และลบไฟล์/โฟลเดอร์เก่าที่ไม่ใช่สองรายการนี้ออกจาก Repository
4. Commit changes
5. เปิด Actions > Build Mobile Installment APK > Run workflow
6. เมื่อสำเร็จ เปิดงานล่าสุด เลื่อนลงไปที่ Artifacts แล้วดาวน์โหลด MobileInstallment-debug-apk

ข้อควรระวัง:
- ห้ามลบโฟลเดอร์ .git (ปกติ GitHub ไม่แสดงและไม่ให้ลบผ่านหน้าเว็บ)
- ต้องวาง .github และ mobile_installment_app ไว้ระดับเดียวกันที่หน้าแรกของ Repository
- ห้ามอัปโหลดไฟล์ ZIP นี้เข้า Repository แทนการแตกไฟล์
- applicationId เดิมคือ com.example.mobileinstallment และ versionCode/versionName ยังคงตามต้นฉบับ
- การติดตั้งทับแอปเดิมต้องใช้ signing certificate เดิม หากลายเซ็นไม่ตรง Android จะไม่ยอมให้อัปเดตทับ
